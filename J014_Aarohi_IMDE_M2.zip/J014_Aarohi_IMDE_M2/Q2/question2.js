/* Implement all JS fundamentals:-
Variable declarations and show their data in an HTML file.
Implement a simple function of addition and as well an arrow function of addition and return their values in an HTML file.
Implement Decision-Making Statements and Loops concept with good examples and explanations. */
let x = 5;
let y = 6;

let z= x+y;

console.log(z);





// <!-- <script src="question2.js"> </script> `